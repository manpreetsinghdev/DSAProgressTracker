
package com.firstapp.dsaprogresstracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class DsaQuestion(
    val id: Int,
    val topic: String,
    val name: String,
    val completed: Boolean
)

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "DSATracker.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL,
                name TEXT NOT NULL,
                completed INTEGER DEFAULT 0
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        // Reserved for future database upgrades.
    }

    fun addQuestion(topic: String, name: String): Boolean {
        val values = ContentValues().apply {
            put("topic", topic)
            put("name", name)
            put("completed", 0)
        }

        return writableDatabase.insert("questions", null, values) != -1L
    }

    fun getAllQuestions(): List<DsaQuestion> {
        val list = mutableListOf<DsaQuestion>()

        val cursor = readableDatabase.rawQuery(
            "SELECT id, topic, name, completed FROM questions ORDER BY id DESC",
            null
        )

        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    DsaQuestion(
                        id = it.getInt(0),
                        topic = it.getString(1),
                        name = it.getString(2),
                        completed = it.getInt(3) == 1
                    )
                )
            }
        }

        return list
    }

    fun updateStatus(id: Int, completed: Boolean) {
        val values = ContentValues().apply {
            put("completed", if (completed) 1 else 0)
        }

        writableDatabase.update(
            "questions",
            values,
            "id = ?",
            arrayOf(id.toString())
        )
    }

    fun deleteQuestion(id: Int) {
        writableDatabase.delete(
            "questions",
            "id = ?",
            arrayOf(id.toString())
        )
    }
}
