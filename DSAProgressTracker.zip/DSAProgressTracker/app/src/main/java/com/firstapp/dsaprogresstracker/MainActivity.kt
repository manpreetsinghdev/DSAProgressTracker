
package com.firstapp.dsaprogresstracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                DSAProgressApp()
            }
        }
    }
}

// Colors
private val Purple = Color(0xFF8B5CF6)
private val Background = Color(0xFF10111A)
private val CardColor = Color(0xFF1C1D2B)
private val InputColor = Color(0xFF292A3B)
private val Green = Color(0xFF4CAF50)
private val White = Color.White
private val Grey = Color(0xFFB0B0B0)

@Composable
fun DSAProgressApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val db = remember { DatabaseHelper(context) }

    var topic by remember { mutableStateOf("") }
    var problemName by remember { mutableStateOf("") }

    var questions by remember {
        mutableStateOf(emptyList<DsaQuestion>())
    }

    fun refresh() {
        questions = db.getAllQuestions()
    }

    LaunchedEffect(Unit) {
        refresh()
    }

    val total = questions.size
    val solved = questions.count { it.completed }
    val progress = if (total == 0) 0f else solved.toFloat() / total

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {

                // Header
                Text(
                    text = "DSA TRACKER",
                    color = Purple,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelLarge
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Your Coding Journey 🚀",
                    color = White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.headlineMedium
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Progress card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = CardColor
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            "Overall Progress",
                            color = White,
                            style = MaterialTheme.typography.titleMedium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "$solved / $total completed",
                                color = Grey
                            )

                            Text(
                                "${(progress * 100).toInt()}%",
                                color = Purple,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = Purple,
                            trackColor = Color.DarkGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Statistics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        "Total",
                        total.toString(),
                        Modifier.weight(1f)
                    )

                    StatCard(
                        "Solved",
                        solved.toString(),
                        Modifier.weight(1f)
                    )

                    StatCard(
                        "Remaining",
                        (total - solved).toString(),
                        Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Add problem card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = CardColor
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {

                        Text(
                            "Add New Problem ✨",
                            color = White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Topic field
                        OutlinedTextField(
                            value = topic,
                            onValueChange = { topic = it },
                            label = {
                                Text(
                                    "Topic",
                                    color = Grey
                                )
                            },
                            placeholder = {
                                Text(
                                    "e.g. Arrays",
                                    color = Grey
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = visibleInputColors()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Problem name field
                        OutlinedTextField(
                            value = problemName,
                            onValueChange = { problemName = it },
                            label = {
                                Text(
                                    "Problem Name",
                                    color = Grey
                                )
                            },
                            placeholder = {
                                Text(
                                    "e.g. Two Sum",
                                    color = Grey
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = visibleInputColors()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Add button
                        Button(
                            onClick = {
                                if (
                                    topic.isNotBlank() &&
                                    problemName.isNotBlank()
                                ) {
                                    val result = db.addQuestion(
                                        topic.trim(),
                                        problemName.trim()
                                    )

                                    if (result) {
                                        topic = ""
                                        problemName = ""
                                        refresh()
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Purple
                            )
                        ) {
                            Text(
                                "+ Add Problem",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // Problems heading
                Text(
                    "Your Problems",
                    color = White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Problem list
                questions.forEach { question ->
                    QuestionCard(
                        question = question,
                        onToggle = {
                            db.updateStatus(
                                question.id,
                                !question.completed
                            )
                            refresh()
                        },
                        onDelete = {
                            db.deleteQuestion(question.id)
                            refresh()
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                }

                if (questions.isEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = CardColor
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "📝",
                                style = MaterialTheme.typography.headlineMedium
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                "No problems yet",
                                color = White,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                "Add your first DSA problem above!",
                                color = Grey
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

// Visible text input colors
@Composable
private fun visibleInputColors() =
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = White,
        unfocusedTextColor = White,
        disabledTextColor = Grey,

        focusedLabelColor = Purple,
        unfocusedLabelColor = Grey,

        focusedPlaceholderColor = Grey,
        unfocusedPlaceholderColor = Grey,

        cursorColor = Purple,

        focusedBorderColor = Purple,
        unfocusedBorderColor = Color.Gray,

        focusedContainerColor = InputColor,
        unfocusedContainerColor = InputColor
    )

// Statistics card
@Composable
fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardColor
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                value,
                color = Purple,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                title,
                color = Grey,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

// Problem card
@Composable
fun QuestionCard(
    question: DsaQuestion,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardColor
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    question.topic,
                    color = Purple,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    question.name,
                    color = White,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyLarge
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    if (question.completed) "Completed ✓" else "Pending",
                    color = if (question.completed) Green else Grey,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Checkbox(
                    checked = question.completed,
                    onCheckedChange = { onToggle() },
                    colors = CheckboxDefaults.colors(
                        checkedColor = Green,
                        uncheckedColor = Grey,
                        checkmarkColor = White
                    )
                )

                TextButton(onClick = onDelete) {
                    Text(
                        "Delete",
                        color = Color(0xFFFF6B6B)
                    )
                }
            }
        }
    }
}
